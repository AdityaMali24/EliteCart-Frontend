import React from 'react'
// import ResponsiveAppBar from './ResponsiveAppBar'
import Navbar from './Navbar'
import HeroSection from './HeroHome'
// import Products from './Products'

const Home = () => {
  return (
    <>
      {/* <Navbar/> */}
      <HeroSection/>
    </>
    
  )
}

export default Home