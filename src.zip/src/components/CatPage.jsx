import React from 'react'
import CategoryPage from './CategoryPage'

const CatPage = () => {
  return (
    <CategoryPage/>
  )
}

export default CatPage